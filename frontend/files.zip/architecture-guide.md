# Intelligent Data Dictionary Agent - Architecture & Implementation Guide

## 📋 Table of Contents
1. [System Overview](#system-overview)
2. [Architecture Design](#architecture-design)
3. [Technology Stack](#technology-stack)
4. [Implementation Roadmap](#implementation-roadmap)
5. [Detailed Component Guide](#detailed-component-guide)
6. [Database Connectivity](#database-connectivity)
7. [AI Integration](#ai-integration)
8. [Deployment Considerations](#deployment-considerations)

---

## 1. System Overview

### Purpose
Build a software solution that connects to enterprise databases and automatically generates comprehensive, AI-enhanced data dictionaries with natural language query capabilities.

### Core Requirements
- ✅ Multi-database connectivity (Snowflake, PostgreSQL, SQL Server, etc.)
- ✅ Automatic schema metadata extraction
- ✅ AI-powered business context generation
- ✅ Data quality analysis
- ✅ Natural language chat interface
- ✅ Multi-format documentation output (JSON, Markdown)
- ✅ Artifact storage for future reference

### Optional Features
- 🔄 Incremental schema updates
- 📊 Data lineage visualization
- 💡 SQL query suggestions
- ⚠️ Data quality alerts

---

## 2. Architecture Design

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (React)                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Database   │  │  Dictionary  │  │     Chat     │      │
│  │  Connection  │  │    Viewer    │  │  Interface   │      │
│  │      UI      │  │              │  │              │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                            │
                    REST API / WebSocket
                            │
┌─────────────────────────────────────────────────────────────┐
│                   Backend (FastAPI)                         │
│                                                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │              API Layer                              │    │
│  │  • Connection Management                            │    │
│  │  • Dictionary Generation                            │    │
│  │  • Chat Endpoints                                   │    │
│  └────────────────────────────────────────────────────┘    │
│                            │                                │
│  ┌────────────────────────────────────────────────────┐    │
│  │         Core Services                               │    │
│  │                                                      │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │    │
│  │  │   Database   │  │   Metadata   │  │    AI    │ │    │
│  │  │  Connector   │  │   Extractor  │  │ Service  │ │    │
│  │  │   Manager    │  │              │  │          │ │    │
│  │  └──────────────┘  └──────────────┘  └──────────┘ │    │
│  │                                                      │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │    │
│  │  │    Data      │  │  Dictionary  │  │   Chat   │ │    │
│  │  │   Quality    │  │  Generator   │  │  Engine  │ │    │
│  │  │   Analyzer   │  │              │  │          │ │    │
│  │  └──────────────┘  └──────────────┘  └──────────┘ │    │
│  └────────────────────────────────────────────────────┘    │
│                            │                                │
│  ┌────────────────────────────────────────────────────┐    │
│  │          Data Layer                                 │    │
│  │  • Metadata Cache (PostgreSQL/SQLite)               │    │
│  │  • Document Storage (File System/S3)                │    │
│  │  • Session Management                               │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                            │
                    Database Drivers
                            │
┌─────────────────────────────────────────────────────────────┐
│                  Target Databases                           │
│  • Snowflake  • PostgreSQL  • SQL Server  • MySQL           │
└─────────────────────────────────────────────────────────────┘
```

### Component Responsibilities

#### Frontend Components
1. **Database Connection UI**: Configure and test database connections
2. **Dictionary Viewer**: Browse and search generated documentation
3. **Chat Interface**: Natural language queries about database schema

#### Backend Services
1. **Database Connector Manager**: Handle multiple database types
2. **Metadata Extractor**: Extract schema, relationships, constraints
3. **Data Quality Analyzer**: Completeness, freshness, statistical analysis
4. **AI Service**: Generate business context and descriptions
5. **Dictionary Generator**: Compile comprehensive documentation
6. **Chat Engine**: Process NL queries and retrieve information

---

## 3. Technology Stack

### Backend
- **Framework**: FastAPI (async support, automatic API docs)
- **Database Drivers**:
  - `snowflake-connector-python` - Snowflake
  - `psycopg2` / `asyncpg` - PostgreSQL
  - `pyodbc` / `pymssql` - SQL Server
  - `mysql-connector-python` - MySQL
- **AI Integration**: 
  - `anthropic` (Claude API)
  - Alternative: `openai` (GPT-4)
- **Data Processing**: `pandas`, `numpy`
- **Caching**: `redis-py` or SQLite for metadata cache
- **Task Queue**: `celery` + Redis (for async metadata extraction)
- **Validation**: `pydantic`

### Frontend
- **Framework**: React 18+ with TypeScript
- **UI Components**: Material-UI (MUI) or Ant Design
- **State Management**: Redux Toolkit or Zustand
- **API Client**: Axios
- **Chat UI**: Custom components with streaming support
- **Data Visualization**: D3.js or Recharts (for lineage diagrams)
- **Markdown Rendering**: `react-markdown`

### Database (Internal)
- **Metadata Storage**: PostgreSQL (for production) or SQLite (for development)
- **Document Storage**: Local filesystem or AWS S3

### DevOps
- **Containerization**: Docker + Docker Compose
- **Environment Management**: python-dotenv
- **Testing**: pytest (backend), Jest + React Testing Library (frontend)

---

## 4. Implementation Roadmap

### Phase 1: Foundation (Week 1-2)
- [ ] Set up project structure
- [ ] Implement database connection manager
- [ ] Create basic metadata extraction for PostgreSQL
- [ ] Set up FastAPI backend with core endpoints
- [ ] Build basic React frontend shell

### Phase 2: Core Features (Week 3-4)
- [ ] Extend database support (Snowflake, SQL Server, MySQL)
- [ ] Implement complete metadata extraction (tables, columns, relationships, constraints)
- [ ] Build data quality analyzer
- [ ] Integrate AI service for business context generation
- [ ] Create dictionary generator with JSON/Markdown output

### Phase 3: Chat Interface (Week 5)
- [ ] Implement chat backend with RAG (Retrieval-Augmented Generation)
- [ ] Build conversational UI
- [ ] Add context-aware query processing
- [ ] Implement streaming responses

### Phase 4: Polish & Optional Features (Week 6-7)
- [ ] Add incremental schema update detection
- [ ] Implement data lineage visualization
- [ ] Create SQL query suggestion engine
- [ ] Add data quality alerts
- [ ] Performance optimization
- [ ] Comprehensive testing

### Phase 5: Deployment (Week 8)
- [ ] Containerization
- [ ] Documentation
- [ ] Security hardening
- [ ] CI/CD pipeline

---

## 5. Detailed Component Guide

### 5.1 Database Connector Manager

**Purpose**: Provide unified interface for multiple database types

**Key Features**:
- Connection pooling
- Credential encryption
- Connection testing
- Support for SSH tunnels (optional)

**Interface**:
```python
class DatabaseConnector:
    def connect(self, credentials: dict) -> Connection
    def test_connection(self, credentials: dict) -> bool
    def disconnect(self, connection_id: str) -> None
    def execute_query(self, connection_id: str, query: str) -> ResultSet
```

### 5.2 Metadata Extractor

**Purpose**: Extract comprehensive schema information

**Extracted Information**:
- Tables: name, type, row count, size
- Columns: name, data type, nullable, default value
- Primary Keys
- Foreign Keys and relationships
- Indexes
- Constraints (unique, check)
- Views
- Stored procedures (optional)

**Process**:
1. Connect to database
2. Query system/information schema tables
3. Parse and normalize metadata
4. Store in internal database

### 5.3 Data Quality Analyzer

**Purpose**: Assess data quality metrics

**Metrics**:
- **Completeness**: Null percentage per column
- **Freshness**: Last update timestamp
- **Uniqueness**: Duplicate detection
- **Statistical Profile**: min, max, mean, median, std dev for numeric columns
- **Pattern Analysis**: Common patterns in string columns
- **Referential Integrity**: FK constraint violations

### 5.4 AI Service

**Purpose**: Generate human-friendly business context

**Capabilities**:
- Table purpose description
- Column semantic meaning
- Usage recommendations
- Data governance notes
- Relationship explanations

**Implementation Strategy**:
```
For each table/column:
1. Gather metadata context
2. Construct AI prompt with:
   - Table/column name
   - Data type
   - Sample values (anonymized)
   - Relationships
   - Statistical profile
3. Call Claude API
4. Parse and store response
```

### 5.5 Dictionary Generator

**Purpose**: Compile all information into documentation

**Output Formats**:
- **JSON**: Machine-readable, API consumption
- **Markdown**: Human-readable, GitHub/wiki
- **HTML**: Web viewing (optional)

**Structure**:
```json
{
  "database": {
    "name": "production_db",
    "type": "postgresql",
    "generated_at": "2025-02-10T10:30:00Z"
  },
  "tables": [
    {
      "name": "customers",
      "description": "AI-generated business description",
      "row_count": 150000,
      "columns": [...],
      "relationships": [...],
      "quality_metrics": {...}
    }
  ]
}
```

### 5.6 Chat Engine

**Purpose**: Enable natural language queries

**Architecture**:
- Vector database (optional): ChromaDB or FAISS for semantic search
- RAG Pipeline: Retrieve relevant schema context, pass to AI
- Conversation memory: Track chat history

**Example Queries**:
- "What tables contain customer information?"
- "Show me the relationship between orders and customers"
- "What are the data quality issues in the sales table?"
- "Generate SQL to find top customers by revenue"

---

## 6. Database Connectivity

### Connection Patterns

#### PostgreSQL
```python
import psycopg2
from psycopg2.extras import RealDictCursor

def connect_postgresql(host, port, database, user, password):
    return psycopg2.connect(
        host=host,
        port=port,
        database=database,
        user=user,
        password=password,
        cursor_factory=RealDictCursor
    )
```

#### Snowflake
```python
import snowflake.connector

def connect_snowflake(account, user, password, warehouse, database, schema):
    return snowflake.connector.connect(
        account=account,
        user=user,
        password=password,
        warehouse=warehouse,
        database=database,
        schema=schema
    )
```

### Metadata Extraction Queries

#### Get Tables (PostgreSQL)
```sql
SELECT 
    table_schema,
    table_name,
    table_type
FROM information_schema.tables
WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
ORDER BY table_schema, table_name;
```

#### Get Columns (PostgreSQL)
```sql
SELECT 
    table_schema,
    table_name,
    column_name,
    data_type,
    is_nullable,
    column_default,
    character_maximum_length
FROM information_schema.columns
WHERE table_schema = %s AND table_name = %s
ORDER BY ordinal_position;
```

#### Get Foreign Keys (PostgreSQL)
```sql
SELECT
    tc.table_schema, 
    tc.table_name,
    kcu.column_name,
    ccu.table_schema AS foreign_table_schema,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
    AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY';
```

---

## 7. AI Integration

### Claude API Integration

#### Setup
```python
from anthropic import Anthropic

client = Anthropic(api_key="your-api-key")
```

#### Generate Table Description
```python
def generate_table_description(table_name, columns, sample_data):
    prompt = f"""
    Analyze this database table and provide a business-friendly description.
    
    Table Name: {table_name}
    
    Columns:
    {columns}
    
    Sample Data (anonymized):
    {sample_data}
    
    Please provide:
    1. A concise description of the table's purpose
    2. The business context and use cases
    3. Key insights about the data
    4. Any recommendations for users
    
    Format your response as JSON with keys: description, business_context, insights, recommendations
    """
    
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        messages=[{"role": "user", "content": prompt}]
    )
    
    return response.content[0].text
```

#### Chat Query Processing
```python
def process_chat_query(user_query, schema_context):
    prompt = f"""
    You are a helpful database assistant. Answer the user's question about the database schema.
    
    Database Schema:
    {schema_context}
    
    User Question: {user_query}
    
    Provide a helpful, accurate answer. If the question involves SQL, generate the appropriate query.
    """
    
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}]
    )
    
    return response.content[0].text
```

### Cost Optimization
- Cache AI-generated descriptions
- Batch process tables when possible
- Use cheaper models for simple tasks
- Implement request throttling

---

## 8. Deployment Considerations

### Security
- **Credentials**: Store encrypted in database or use secrets manager (AWS Secrets Manager, HashiCorp Vault)
- **API Keys**: Never commit to repository, use environment variables
- **Database Access**: Principle of least privilege - read-only access when possible
- **Authentication**: Implement user authentication (JWT tokens)
- **HTTPS**: Always use TLS for API communication

### Scalability
- **Async Processing**: Use Celery for long-running metadata extraction tasks
- **Caching**: Redis for frequently accessed metadata
- **Connection Pooling**: Limit concurrent database connections
- **Rate Limiting**: Protect API endpoints

### Monitoring
- **Logging**: Structured logging (JSON format)
- **Metrics**: Track API response times, error rates
- **Alerts**: Failed connections, data quality degradation
- **Health Checks**: /health endpoint for uptime monitoring

### Performance
- **Database Indexes**: On internal metadata tables
- **Lazy Loading**: Fetch detailed metadata on-demand
- **Pagination**: For large schema browsers
- **Compression**: Gzip API responses

---

## Next Steps

1. Review this architecture document
2. Set up development environment
3. Proceed to implementation guides for:
   - Backend API structure
   - Database connector implementation
   - Frontend application
   - Deployment configuration

Let me know which component you'd like to dive into first!
