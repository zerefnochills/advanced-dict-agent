# Intelligent Data Dictionary Agent

An AI-powered platform for automatically generating comprehensive database documentation with natural language query capabilities.

## 📋 Overview

This application connects to enterprise databases (PostgreSQL, MySQL, SQL Server, Snowflake) and automatically generates detailed data dictionaries enhanced with AI-generated business context, data quality metrics, and an interactive chat interface for natural language queries.

## 🎯 Features

### Core Features
- ✅ Multi-database connectivity (PostgreSQL, MySQL, SQL Server, Snowflake)
- ✅ Automatic schema metadata extraction
- ✅ AI-powered business context generation (using Claude API)
- ✅ Comprehensive data quality analysis
- ✅ Natural language chat interface
- ✅ Multiple export formats (JSON, Markdown)

### Data Quality Metrics
- Completeness analysis (null percentages)
- Uniqueness detection (duplicates)
- Statistical profiling (min/max/mean/median)
- Pattern analysis for text fields
- Data freshness scoring
- Quality score calculation (0-100)

### Optional Features (Extensible)
- Incremental schema update detection
- Data lineage visualization
- SQL query suggestions from natural language
- Data quality alerts and monitoring

## 🏗️ Architecture

```
Frontend (React + TypeScript + Material-UI)
    ↕ REST API / WebSocket
Backend (FastAPI + Python)
    ├── Database Connector Manager
    ├── Metadata Extractor
    ├── AI Service (Claude API)
    ├── Data Quality Analyzer
    ├── Dictionary Generator
    └── Chat Engine
    ↕
Internal DB (PostgreSQL) + Redis Cache
    ↕
Target Databases (PostgreSQL, MySQL, SQL Server, Snowflake)
```

## 📦 Tech Stack

### Backend
- **Framework**: FastAPI
- **Database Drivers**: psycopg2, snowflake-connector-python, pyodbc, mysql-connector-python
- **AI**: Anthropic Claude API
- **Data Processing**: pandas, numpy
- **Caching**: Redis
- **Task Queue**: Celery

### Frontend
- **Framework**: React 18 with TypeScript
- **UI Library**: Material-UI (MUI)
- **HTTP Client**: Axios
- **State Management**: React Hooks

### DevOps
- **Containerization**: Docker & Docker Compose
- **Database**: PostgreSQL (internal metadata)
- **Cache/Queue**: Redis

## 🚀 Quick Start

### Prerequisites
- Docker and Docker Compose (recommended)
- OR: Python 3.11+, Node.js 18+, PostgreSQL, Redis
- Anthropic API key (get one at https://console.anthropic.com)

### Option 1: Docker Compose (Recommended)

1. **Clone the repository**
```bash
git clone <your-repo>
cd intelligent-data-dictionary-agent
```

2. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

3. **Start all services**
```bash
docker-compose up -d
```

4. **Access the application**
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Documentation: http://localhost:8000/docs

### Option 2: Manual Setup

#### Backend Setup

1. **Create virtual environment**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables**
```bash
cp ../.env.example .env
# Edit .env with your configuration
```

4. **Initialize database**
```bash
# Make sure PostgreSQL is running
python -c "from app.core.database import init_db; import asyncio; asyncio.run(init_db())"
```

5. **Start the server**
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

#### Frontend Setup

1. **Install dependencies**
```bash
cd frontend
npm install
```

2. **Configure environment**
```bash
# Create .env.local
echo "REACT_APP_API_URL=http://localhost:8000/api" > .env.local
```

3. **Start development server**
```bash
npm start
```

## 📖 Usage Guide

### 1. Connect to Database

1. Open the application at http://localhost:3000
2. Navigate to the "Connections" tab
3. Fill in your database credentials:
   - **PostgreSQL**: host, port (5432), database, username, password
   - **Snowflake**: account, warehouse, database, username, password
   - **SQL Server**: host, port (1433), database, username, password
   - **MySQL**: host, port (3306), database, username, password
4. Click "Test Connection" to verify
5. Click "Save & Connect" to establish connection

### 2. Generate Data Dictionary

1. After connecting, go to the "Data Dictionary" tab
2. Choose generation options:
   - ✅ Include AI-generated descriptions (recommended)
   - ✅ Include data quality analysis (recommended)
   - ☐ Include sample data (slower, optional)
3. Click "Generate Dictionary"
4. Wait for processing (may take 1-5 minutes depending on database size)

### 3. Review Dictionary

The generated dictionary includes:

- **Overview**: Total tables, columns, database type
- **Table Details**:
  - Row counts
  - Column definitions (name, type, nullable, keys)
  - AI-generated descriptions
  - Data quality scores
  - Quality issues and recommendations
  - Primary and foreign key relationships

### 4. Export Documentation

- Click "Download JSON" for machine-readable format
- Click "Download Markdown" for human-readable documentation
- Use exported files in your wikis, documentation sites, or version control

### 5. Chat with Your Schema

1. Navigate to the "Chat Assistant" tab
2. Ask natural language questions:
   - "What tables contain customer information?"
   - "Show me the relationship between orders and customers"
   - "What are the data quality issues in the sales table?"
   - "Which columns are nullable in the users table?"
   - "Generate SQL to find customers with orders in the last 30 days"
3. Get instant AI-powered answers with context from your schema

## 🔧 Configuration

### AI Provider Configuration

By default, the application uses Anthropic's Claude. To configure:

```env
# .env file
ANTHROPIC_API_KEY=your-key-here
AI_PROVIDER=anthropic
AI_MODEL=claude-sonnet-4-20250514
```

To use OpenAI instead:
```env
OPENAI_API_KEY=your-openai-key
AI_PROVIDER=openai
AI_MODEL=gpt-4
```

### Database Configuration

For internal metadata storage:

**PostgreSQL (Production)**:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/data_dictionary
```

**SQLite (Development)**:
```env
DATABASE_URL=sqlite:///./data_dictionary.db
```

### Redis Configuration

For caching and task queues:
```env
REDIS_URL=redis://localhost:6379/0
REDIS_ENABLED=True
```

## 🧪 Testing

### Backend Tests
```bash
cd backend
pytest
```

### Frontend Tests
```bash
cd frontend
npm test
```

## 📊 API Documentation

Once the backend is running, visit http://localhost:8000/docs for interactive API documentation (Swagger UI).

### Key Endpoints

**Connections**:
- `POST /api/connections/test` - Test database connection
- `POST /api/connections/create` - Save connection
- `GET /api/connections/list` - List saved connections

**Dictionary**:
- `POST /api/dictionary/generate` - Generate data dictionary
- `GET /api/dictionary/{connection_id}/tables` - List tables
- `GET /api/dictionary/{connection_id}/tables/{schema}/{table}/columns` - Get columns
- `POST /api/dictionary/{connection_id}/tables/{schema}/{table}/analyze` - Analyze table quality

**Chat**:
- `POST /api/chat/query` - Send chat query
- `GET /api/chat/history` - Get chat history

## 🔐 Security Best Practices

1. **Never commit `.env` file** - Add to `.gitignore`
2. **Use environment variables** for all secrets
3. **Encrypt database passwords** in storage
4. **Use read-only database accounts** when possible
5. **Enable HTTPS** in production
6. **Implement rate limiting** on API endpoints
7. **Use strong SECRET_KEY** and ENCRYPTION_KEY

## 🐛 Troubleshooting

### Connection Issues

**Problem**: "Connection test failed"
- Verify database is accessible from your network
- Check firewall rules
- Confirm credentials are correct
- For Snowflake, ensure account identifier is correct (e.g., `abc123.us-east-1`)

### AI Generation Issues

**Problem**: "Failed to generate AI descriptions"
- Verify `ANTHROPIC_API_KEY` is set correctly
- Check API quota/limits
- Ensure internet connectivity
- Review logs for specific error messages

### Performance Issues

**Problem**: "Dictionary generation is slow"
- Enable Redis caching (`REDIS_ENABLED=True`)
- Reduce `SAMPLE_SIZE` for quality analysis
- Disable "Include sample data" option
- Use Celery for background processing

### Docker Issues

**Problem**: "Container won't start"
```bash
# Check logs
docker-compose logs backend
docker-compose logs frontend

# Rebuild containers
docker-compose down
docker-compose up --build
```

## 📁 Project Structure

```
intelligent-data-dictionary-agent/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   └── routes/
│   │   │       ├── connections.py
│   │   │       ├── dictionary.py
│   │   │       ├── chat.py
│   │   │       └── health.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   └── database.py
│   │   └── services/
│   │       ├── database_connector.py
│   │       ├── metadata_extractor.py
│   │       ├── ai_service.py
│   │       └── data_quality_analyzer.py
│   ├── main.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ConnectionManager.tsx
│   │   │   ├── DictionaryViewer.tsx
│   │   │   └── ChatInterface.tsx
│   │   ├── App.tsx
│   │   └── index.tsx
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

## 🎓 Implementation Roadmap

Refer to `architecture-guide.md` for detailed implementation phases:

- ✅ **Phase 1**: Foundation (Weeks 1-2)
- ✅ **Phase 2**: Core Features (Weeks 3-4)
- ✅ **Phase 3**: Chat Interface (Week 5)
- ⚠️ **Phase 4**: Optional Features (Weeks 6-7)
- ⚠️ **Phase 5**: Deployment (Week 8)

## 🚢 Deployment

### Production Deployment

1. **Update environment variables** for production
2. **Use production database** (PostgreSQL, not SQLite)
3. **Enable HTTPS** with reverse proxy (nginx/Caddy)
4. **Set up monitoring** (logging, metrics, alerts)
5. **Configure backups** for internal metadata database
6. **Use managed services** for Redis and PostgreSQL if possible

### Deployment Options

**Docker + Cloud**:
- AWS: ECS/Fargate + RDS + ElastiCache
- Google Cloud: Cloud Run + Cloud SQL + Memorystore
- Azure: Container Instances + Azure Database + Redis Cache

**Platform-as-a-Service**:
- Railway.app
- Render.com
- Heroku

## 📝 License

[Specify your license]

## 🤝 Contributing

[Contribution guidelines]

## 📧 Support

For issues and questions:
- GitHub Issues: [your-repo-issues]
- Email: [your-email]

## 🙏 Acknowledgments

- Built with FastAPI and React
- Powered by Anthropic Claude
- UI components from Material-UI

---

**Note**: This is a comprehensive implementation guide. For detailed technical documentation, refer to `architecture-guide.md`.
